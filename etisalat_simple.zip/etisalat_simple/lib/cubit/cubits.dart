import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../data/repositories.dart';
import '../model/models.dart';

// ======================= المستخدم =======================
class UserState extends Equatable {
  const UserState({this.user, this.balance = 0, this.loading = true});
  final UserModel? user;
  final double balance;
  final bool loading;
  @override
  List<Object?> get props => [user?.id, balance, loading];
}

class UserCubit extends Cubit<UserState> {
  UserCubit(this._users, this._settings) : super(const UserState());

  final UserRepository _users;
  final SettingsRepository _settings;

  String? phone;

  Future<void> createProfile(String name, String phone) async {
    await _users.create(name, phone);
    await _settings.set('current_phone', phone);
    await load();
  }

  Future<void> load() async {
    phone = await _settings.get('current_phone');
    if (phone == null) return emit(const UserState(loading: false));
    final u = await _users.byPhone(phone!);
    if (u == null) return emit(const UserState(loading: false));
    final b = u == null ? 0.0 : await _users.balance(phone!);
    emit(UserState(user: u, balance: b, loading: false));
  }
}

// ======================= المعاملات =======================
class TransactionState extends Equatable {
  const TransactionState({this.items = const [], this.filter = TransactionFilter.empty, this.loading = true});
  final List<AppTransaction> items;
  final TransactionFilter filter;
  final bool loading;
  @override
  List<Object?> get props => [items, filter.from, filter.to, filter.phone, filter.type, loading];
}

class TransactionCubit extends Cubit<TransactionState> {
  TransactionCubit(this._repo, this._settings) : super(const TransactionState());
  final TransactionRepository _repo;
  final SettingsRepository _settings;

  Future<void> load([TransactionFilter? filter]) async {
    final f = filter ?? state.filter;
    final phone = await _settings.get('current_phone');
    if (phone == null) return emit(TransactionState(filter: f, loading: false));
    final items = await _repo.query(userPhone: phone, filter: f);
    emit(TransactionState(items: items, filter: f, loading: false));
  }

  Future<void> add({required String name, required String phone, required double amount, required String type, String? note}) async {
    final me = await _settings.get('current_phone');
    if (me == null) return;
    await _repo.insert(AppTransaction(
        userPhone: me, name: name, phone: phone, amount: amount, type: type, note: note, createdAt: DateTime.now()));
    await load();
  }

  Future<void> delete(int id) async {
    await _repo.delete(id);
    await load();
  }
}

// ======================= الإشعارات =======================
class NotificationState extends Equatable {
  const NotificationState({this.items = const [], this.loading = true});
  final List<NotificationModel> items;
  final bool loading;
  int get unread => items.where((e) => !e.isRead).length;
  @override
  List<Object?> get props => [items.map((e) => '${e.id}${e.isRead}').join(','), loading];
}

class NotificationCubit extends Cubit<NotificationState> {
  NotificationCubit(this._repo) : super(const NotificationState());
  final NotificationRepository _repo;

  Future<void> load() async => emit(NotificationState(items: await _repo.all(), loading: false));

  Future<void> markRead(NotificationModel n) async {
    if (n.isRead || n.id == null) return;
    await _repo.markRead(n.id!);
    await load();
  }
}
