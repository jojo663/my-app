import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../core/extensions.dart';
import '../model/models.dart';

class PdfFileService {
  static Future<void> exportTransactions(List<AppTransaction> items, {required String title}) async {
    final font = await PdfGoogleFonts.amiriRegular(); // يحتاج إنترنت أول مرة
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: font, bold: font));
    final total = items.fold<double>(0, (s, t) => s + t.signedAmount);

    doc.addPage(pw.MultiPage(
      textDirection: pw.TextDirection.rtl,
      build: (_) => [
        pw.Header(level: 0, child: pw.Text(title, style: const pw.TextStyle(fontSize: 22))),
        pw.Text('عدد المعاملات: ${items.length}'),
        pw.Text('الصافي: ${total.money}'),
        pw.SizedBox(height: 12),
        pw.TableHelper.fromTextArray(
          headers: ['التاريخ', 'النوع', 'الاسم', 'الرقم', 'المبلغ'],
          data: [
            for (final t in items)
              [t.createdAt.ymdHm, t.isSend ? 'إرسال' : 'استلام', t.name, t.phone, t.amount.money],
          ],
          cellAlignment: pw.Alignment.centerRight,
        ),
      ],
    ));
    await Printing.sharePdf(bytes: await doc.save(), filename: 'transactions.pdf');
  }
}
