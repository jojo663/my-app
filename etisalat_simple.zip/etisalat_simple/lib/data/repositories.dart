import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:sqflite/sqflite.dart';

import '../core/app_database.dart';
import '../model/models.dart';

class SettingsRepository {
  SettingsRepository(this._d);
  final AppDatabase _d;

  Future<String?> get(String key) async {
    final r = await _d.db.query('settings', where: 'key = ?', whereArgs: [key], limit: 1);
    return r.isEmpty ? null : r.first['value'] as String?;
  }

  Future<void> set(String key, String value) async {
    await _d.db.insert('settings', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> remove(String key) async {
    await _d.db.delete('settings', where: 'key = ?', whereArgs: [key]);
  }

  static String hash(String s) =>
      sha256.convert(utf8.encode('etisalat_app::$s')).toString();

}

class UserRepository {
  UserRepository(this._d);
  final AppDatabase _d;

  Future<UserModel?> byPhone(String phone) async {
    final r = await _d.db.query('users', where: 'phone = ?', whereArgs: [phone], limit: 1);
    return r.isEmpty ? null : UserModel.fromMap(r.first);
  }

  Future<void> create(String name, String phone) async {
    await _d.db.insert(
      'users',
      UserModel(name: name, phone: phone, createdAt: DateTime.now()).toMap()..remove('id'),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<UserModel>> all() async {
    final r = await _d.db.query('users', orderBy: 'id DESC');
    return r.map(UserModel.fromMap).toList();
  }

  Future<double> balance(String phone) async {
    final r = await _d.db.rawQuery(
      "SELECT COALESCE(SUM(CASE WHEN type = 'receive' THEN amount ELSE -amount END), 0) AS b "
      'FROM transactions WHERE user_phone = ?',
      [phone],
    );
    return (r.first['b'] as num).toDouble();
  }

  Future<void> delete(UserModel u) async {
    await _d.db.transaction((txn) async {
      await txn.delete('transactions', where: 'user_phone = ?', whereArgs: [u.phone]);
      await txn.delete('users', where: 'id = ?', whereArgs: [u.id]);
    });
  }
}

class TransactionFilter {
  const TransactionFilter({this.from, this.to, this.phone = '', this.type});
  final DateTime? from;
  final DateTime? to;
  final String phone;
  final String? type; // null = الكل
  static const empty = TransactionFilter();
  bool get isEmpty => from == null && to == null && phone.isEmpty && type == null;
}

class TransactionRepository {
  TransactionRepository(this._d);
  final AppDatabase _d;

  Future<List<AppTransaction>> query({String? userPhone, TransactionFilter filter = TransactionFilter.empty}) async {
    final where = <String>[];
    final args = <Object?>[];
    if (userPhone != null) {
      where.add('user_phone = ?');
      args.add(userPhone);
    }
    if (filter.from != null) {
      where.add('created_at >= ?');
      args.add(DateTime(filter.from!.year, filter.from!.month, filter.from!.day).toIso8601String());
    }
    if (filter.to != null) {
      where.add('created_at < ?');
      args.add(DateTime(filter.to!.year, filter.to!.month, filter.to!.day).add(const Duration(days: 1)).toIso8601String());
    }
    if (filter.phone.isNotEmpty) {
      where.add('phone LIKE ?');
      args.add('%${filter.phone}%');
    }
    if (filter.type != null) {
      where.add('type = ?');
      args.add(filter.type);
    }
    final r = await _d.db.query('transactions',
        where: where.isEmpty ? null : where.join(' AND '), whereArgs: args, orderBy: 'created_at DESC');
    return r.map(AppTransaction.fromMap).toList();
  }

  Future<void> insert(AppTransaction t) async {
    await _d.db.insert('transactions', t.toMap()..remove('id'));
  }

  Future<void> delete(int id) async {
    await _d.db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }
}

class NotificationRepository {
  NotificationRepository(this._d);
  final AppDatabase _d;

  Future<List<NotificationModel>> all() async {
    final r = await _d.db.query('notifications', orderBy: 'id DESC');
    return r.map(NotificationModel.fromMap).toList();
  }

  Future<void> add(String title, String body) async {
    await _d.db.insert(
        'notifications',
        NotificationModel(title: title, body: body, createdAt: DateTime.now()).toMap()..remove('id'));
  }

  Future<void> markRead(int id) async {
    await _d.db.update('notifications', {'is_read': 1}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> delete(int id) async {
    await _d.db.delete('notifications', where: 'id = ?', whereArgs: [id]);
  }
}
