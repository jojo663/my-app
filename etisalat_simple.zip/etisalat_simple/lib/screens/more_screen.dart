import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../core/extensions.dart';
import '../data/repositories.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المزيد')),
      body: ListView(children: [
        ListTile(
          leading: const Icon(Icons.lock_outline),
          title: const Text('كلمة مرور المحفظة'),
          subtitle: const Text('حماية شاشة المعاملات'),
          onTap: () => context.sheet(const _WalletPasswordSheet()),
        ),
      ]),
    );
  }
}

class _WalletPasswordSheet extends StatefulWidget {
  const _WalletPasswordSheet();
  @override
  State<_WalletPasswordSheet> createState() => _WalletPasswordSheetState();
}

class _WalletPasswordSheetState extends State<_WalletPasswordSheet> {
  final _pw = TextEditingController();

  @override
  void dispose() {
    _pw.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.read<SettingsRepository>();
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('كلمة مرور المحفظة', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      TextField(
        controller: _pw,
        obscureText: true,
        decoration: const InputDecoration(labelText: 'كلمة مرور جديدة', border: OutlineInputBorder()),
      ),
      const SizedBox(height: 12),
      FilledButton(
        onPressed: () async {
          if (_pw.text.length < 4) return context.toast('4 أحرف على الأقل');
          final nav = Navigator.of(context);
          await settings.set('wallet_hash', SettingsRepository.hash(_pw.text));
          nav.pop();
          if (context.mounted) context.toast('تم الحفظ — ستُطلب عند فتح المعاملات بعد إعادة تشغيل التطبيق');
        },
        child: const Text('حفظ'),
      ),
      TextButton(
        onPressed: () async {
          final nav = Navigator.of(context);
          await settings.remove('wallet_hash');
          nav.pop();
        },
        child: const Text('إزالة كلمة المرور'),
      ),
    ]);
  }
}
