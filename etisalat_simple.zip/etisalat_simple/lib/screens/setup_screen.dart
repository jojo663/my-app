import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../core/extensions.dart';
import '../cubit/cubits.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    await context.read<UserCubit>().createProfile(_name.text.trim(), _phone.text.trim());
    if (mounted) {
      context.read<TransactionCubit>().load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('مرحباً')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _form,
            child: ListView(children: [
              const SizedBox(height: 16),
              Icon(Icons.account_circle_outlined, size: 72, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 16),
              const Text('اكتب بياناتك للبدء', textAlign: TextAlign.center),
              const SizedBox(height: 24),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'الاسم', border: OutlineInputBorder()),
                validator: (v) => (v == null || v.trim().length < 3) ? 'اكتب الاسم' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _phone,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الموبايل', border: OutlineInputBorder()),
                validator: (v) => (v ?? '').trim().isValidEgPhone ? null : 'رقم موبايل مصري غير صحيح',
              ),
              const SizedBox(height: 20),
              FilledButton(onPressed: _save, child: const Text('ابدأ')),
            ]),
          ),
        ),
      ),
    );
  }
}
