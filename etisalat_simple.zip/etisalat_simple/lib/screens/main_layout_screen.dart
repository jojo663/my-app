import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../core/extensions.dart';
import '../cubit/cubits.dart';
import 'more_screen.dart';
import 'notification_screen.dart';
import 'transaction_screen.dart';

class MainLayoutScreen extends StatefulWidget {
  const MainLayoutScreen({super.key});
  @override
  State<MainLayoutScreen> createState() => _MainLayoutScreenState();
}

class _MainLayoutScreenState extends State<MainLayoutScreen> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final unread = context.watch<NotificationCubit>().state.unread;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: _i, children: const [
          HomeScreen(),
          TransactionScreen(),
          NotificationScreen(),
          MoreScreen(),
        ]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (v) => setState(() => _i = v),
          destinations: [
            const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            const NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'المعاملات'),
            NavigationDestination(
              icon: Badge(isLabelVisible: unread > 0, label: Text('$unread'), child: const Icon(Icons.notifications_none)),
              selectedIcon: const Icon(Icons.notifications),
              label: 'الإشعارات',
            ),
            const NavigationDestination(icon: Icon(Icons.menu), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<UserCubit>().state;
    final txs = context.watch<TransactionCubit>().state.items;
    final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: Text('أهلاً ${user.user?.name ?? ''}')),
      body: RefreshIndicator(
        onRefresh: () async {
          await context.read<UserCubit>().load();
          await context.read<TransactionCubit>().load();
        },
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Card(
            color: cs.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(user.user?.phone ?? '', style: Theme.of(context).textTheme.bodyMedium),
                const SizedBox(height: 8),
                const Text('الرصيد'),
                Text(user.balance.money, style: Theme.of(context).textTheme.headlineMedium),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _QuickAction(Icons.north_east, 'إرسال', () => showAddTransaction(context, 'send'))),
            const SizedBox(width: 12),
            Expanded(child: _QuickAction(Icons.south_west, 'استلام', () => showAddTransaction(context, 'receive'))),
          ]),
          const SizedBox(height: 20),
          Text('آخر المعاملات', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (txs.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('لا توجد معاملات بعد')))
          else for (final t in txs.take(5)) TransactionTile(t),
        ]),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  const _QuickAction(this.icon, this.label, this.onTap);
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => FilledButton.tonalIcon(onPressed: onTap, icon: Icon(icon), label: Text(label));
}
