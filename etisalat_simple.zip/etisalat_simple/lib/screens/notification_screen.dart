import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../core/extensions.dart';
import '../cubit/cubits.dart';

class NotificationScreen extends StatelessWidget {
  const NotificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<NotificationCubit>().state;
    return Scaffold(
      appBar: AppBar(title: const Text('الإشعارات')),
      body: RefreshIndicator(
        onRefresh: () => context.read<NotificationCubit>().load(),
        child: state.items.isEmpty
            ? ListView(children: const [SizedBox(height: 200), Center(child: Text('لا توجد إشعارات'))])
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: state.items.length,
                itemBuilder: (_, i) {
                  final n = state.items[i];
                  return Card(
                    child: ListTile(
                      leading: Icon(n.isRead ? Icons.notifications_none : Icons.notifications_active,
                          color: n.isRead ? null : Theme.of(context).colorScheme.primary),
                      title: Text(n.title, style: TextStyle(fontWeight: n.isRead ? FontWeight.normal : FontWeight.bold)),
                      subtitle: Text('${n.body}\n${n.createdAt.ymdHm}'),
                      isThreeLine: true,
                      onTap: () => context.read<NotificationCubit>().markRead(n),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
