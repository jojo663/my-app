import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../core/extensions.dart';
import '../cubit/cubits.dart';
import '../data/pdf_file_service.dart';
import '../data/repositories.dart';
import '../model/models.dart';

class TransactionScreen extends StatefulWidget {
  const TransactionScreen({super.key});
  @override
  State<TransactionScreen> createState() => _TransactionScreenState();
}

class _TransactionScreenState extends State<TransactionScreen> {
  bool? _locked; // null = جاري التحقق

  @override
  void initState() {
    super.initState();
    context.read<SettingsRepository>().get('wallet_hash').then((h) {
      if (mounted) setState(() => _locked = h != null);
    });
  }

  Future<void> _unlock() async {
    final settings = context.read<SettingsRepository>();
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('كلمة مرور المحفظة'),
          content: TextField(controller: ctrl, obscureText: true, autofocus: true,
              decoration: const InputDecoration(border: OutlineInputBorder())),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            FilledButton(
              onPressed: () async {
                final saved = await settings.get('wallet_hash');
                if (ctx.mounted) Navigator.pop(ctx, saved == SettingsRepository.hash(ctrl.text));
              },
              child: const Text('فتح'),
            ),
          ],
        ),
      ),
    );
    ctrl.dispose();
    if (!mounted) return;
    if (ok == true) {
      setState(() => _locked = false);
    } else if (ok == false) {
      context.toast('كلمة المرور غير صحيحة');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_locked == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_locked == true) {
      return Scaffold(
        appBar: AppBar(title: const Text('المعاملات')),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.lock_outline, size: 64),
            const SizedBox(height: 12),
            const Text('المعاملات محمية بكلمة مرور'),
            const SizedBox(height: 12),
            FilledButton(onPressed: _unlock, child: const Text('فتح')),
          ]),
        ),
      );
    }
    return const _TransactionList();
  }
}

class _TransactionList extends StatelessWidget {
  const _TransactionList();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<TransactionCubit>().state;
    return Scaffold(
      appBar: AppBar(
        title: const Text('المعاملات'),
        actions: [
          IconButton(
            tooltip: 'فلترة',
            icon: Badge(isLabelVisible: !state.filter.isEmpty, smallSize: 8, child: const Icon(Icons.filter_list)),
            onPressed: () => context.sheet(_FilterSheet(initial: state.filter)),
          ),
          IconButton(
            tooltip: 'تصدير PDF',
            icon: const Icon(Icons.picture_as_pdf_outlined),
            onPressed: state.items.isEmpty
                ? null
                : () async {
                    try {
                      await PdfFileService.exportTransactions(state.items, title: 'كشف المعاملات');
                    } catch (e) {
                      if (context.mounted) context.toast('تعذر إنشاء الملف: $e');
                    }
                  },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showAddTransaction(context, 'send'),
        child: const Icon(Icons.add),
      ),
      body: state.loading
          ? const Center(child: CircularProgressIndicator())
          : state.items.isEmpty
              ? Center(child: Text(state.filter.isEmpty ? 'لا توجد معاملات' : 'لا توجد نتائج مطابقة'))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
                  itemCount: state.items.length,
                  itemBuilder: (_, i) => TransactionTile(state.items[i], deletable: true),
                ),
    );
  }
}

class TransactionTile extends StatelessWidget {
  const TransactionTile(this.t, {super.key, this.deletable = false});
  final AppTransaction t;
  final bool deletable;

  @override
  Widget build(BuildContext context) {
    final color = t.isSend ? Colors.red.shade700 : Colors.green.shade700;
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(.12),
          child: Icon(t.isSend ? Icons.north_east : Icons.south_west, color: color),
        ),
        title: Text(t.name),
        subtitle: Text('${t.phone}\n${t.createdAt.ymdHm}${(t.note ?? '').isEmpty ? '' : '\n${t.note}'}'),
        isThreeLine: true,
        trailing: Text('${t.isSend ? '-' : '+'}${t.amount.money}', style: TextStyle(color: color, fontWeight: FontWeight.bold)),
        onLongPress: !deletable
            ? null
            : () async {
                final cubit = context.read<TransactionCubit>();
                final user = context.read<UserCubit>();
                if (await context.confirm('حذف هذه المعاملة؟')) {
                  await cubit.delete(t.id!);
                  await user.load();
                }
              },
      ),
    );
  }
}

// ---------------- إضافة معاملة ----------------
void showAddTransaction(BuildContext context, String type) => context.sheet(_AddSheet(type: type));

class _AddSheet extends StatefulWidget {
  const _AddSheet({required this.type});
  final String type;
  @override
  State<_AddSheet> createState() => _AddSheetState();
}

class _AddSheetState extends State<_AddSheet> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  late String _type = widget.type;

  @override
  void dispose() {
    for (final c in [_name, _phone, _amount, _note]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final tx = context.read<TransactionCubit>();
    final user = context.read<UserCubit>();
    final nav = Navigator.of(context);
    final notes = context.read<NotificationRepository>();
    final notifCubit = context.read<NotificationCubit>();
    final amountValue = double.parse(_amount.text.replaceAll(',', '.'));
    await tx.add(
      name: _name.text.trim(),
      phone: _phone.text.trim(),
      amount: amountValue,
      type: _type,
      note: _note.text.trim().isEmpty ? null : _note.text.trim(),
    );
    await user.load();
    await notes.add(_type == 'send' ? 'تم الإرسال' : 'تم الاستلام',
        '${amountValue.money} ${_type == 'send' ? 'إلى' : 'من'} ${_name.text.trim()}');
    await notifCubit.load();
    nav.pop();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text('معاملة جديدة', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'send', label: Text('إرسال'), icon: Icon(Icons.north_east)),
            ButtonSegment(value: 'receive', label: Text('استلام'), icon: Icon(Icons.south_west)),
          ],
          selected: {_type},
          onSelectionChanged: (s) => setState(() => _type = s.first),
        ),
        const SizedBox(height: 12),
        TextFormField(
          controller: _name,
          decoration: const InputDecoration(labelText: 'الاسم', border: OutlineInputBorder()),
          validator: (v) => (v ?? '').trim().isEmpty ? 'مطلوب' : null,
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _phone,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(labelText: 'الرقم', border: OutlineInputBorder()),
          validator: (v) => (v ?? '').trim().isValidEgPhone ? null : 'رقم موبايل مصري غير صحيح',
        ),
        const SizedBox(height: 10),
        TextFormField(
          controller: _amount,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'المبلغ', border: OutlineInputBorder()),
          validator: (v) {
            final n = double.tryParse((v ?? '').replaceAll(',', '.'));
            return (n == null || n <= 0) ? 'مبلغ غير صحيح' : null;
          },
        ),
        const SizedBox(height: 10),
        TextFormField(controller: _note, decoration: const InputDecoration(labelText: 'ملاحظة (اختياري)', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        FilledButton(onPressed: _save, child: const Text('حفظ')),
      ]),
    );
  }
}

// ---------------- الفلترة ----------------
class _FilterSheet extends StatefulWidget {
  const _FilterSheet({required this.initial});
  final TransactionFilter initial;
  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  late DateTime? _from = widget.initial.from;
  late DateTime? _to = widget.initial.to;
  late String? _type = widget.initial.type;
  late final _phone = TextEditingController(text: widget.initial.phone);

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  Future<void> _pickRange() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 1)),
      initialDateRange: _from != null && _to != null ? DateTimeRange(start: _from!, end: _to!) : null,
    );
    if (r != null) setState(() {
      _from = r.start;
      _to = r.end;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('فلترة المعاملات', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 12),
      OutlinedButton.icon(
        onPressed: _pickRange,
        icon: const Icon(Icons.date_range),
        label: Text(_from == null ? 'اختر الفترة' : '${_from!.ymd}  →  ${_to!.ymd}'),
      ),
      const SizedBox(height: 10),
      TextField(
        controller: _phone,
        keyboardType: TextInputType.phone,
        decoration: const InputDecoration(labelText: 'بحث برقم', border: OutlineInputBorder()),
      ),
      const SizedBox(height: 10),
      Wrap(spacing: 8, children: [
        ChoiceChip(label: const Text('الكل'), selected: _type == null, onSelected: (_) => setState(() => _type = null)),
        ChoiceChip(label: const Text('إرسال'), selected: _type == 'send', onSelected: (_) => setState(() => _type = 'send')),
        ChoiceChip(label: const Text('استلام'), selected: _type == 'receive', onSelected: (_) => setState(() => _type = 'receive')),
      ]),
      const SizedBox(height: 16),
      Row(children: [
        Expanded(
          child: OutlinedButton(
            onPressed: () {
              context.read<TransactionCubit>().load(TransactionFilter.empty);
              Navigator.pop(context);
            },
            child: const Text('مسح'),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: FilledButton(
            onPressed: () {
              context.read<TransactionCubit>().load(
                  TransactionFilter(from: _from, to: _to, phone: _phone.text.trim(), type: _type));
              Navigator.pop(context);
            },
            child: const Text('تطبيق'),
          ),
        ),
      ]),
    ]);
  }
}
