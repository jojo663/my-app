import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

extension DateTimeX on DateTime {
  String get ymdHm => DateFormat('yyyy/MM/dd  HH:mm').format(this);
  String get ymd => DateFormat('yyyy/MM/dd').format(this);
}

extension NumX on num {
  String get money => '${NumberFormat('#,##0.00').format(this)} ج.م';
}

extension ContextX on BuildContext {
  void toast(String message) => ScaffoldMessenger.of(this)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(message)));

  Future<T?> sheet<T>(Widget child) => showModalBottomSheet<T>(
        context: this,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (ctx) => Directionality(
          textDirection: TextDirection.rtl,
          child: Padding(
            padding: EdgeInsets.fromLTRB(20, 4, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
            child: SingleChildScrollView(child: child),
          ),
        ),
      );

  Future<bool> confirm(String message) async {
    final r = await showDialog<bool>(
      context: this,
      builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          content: Text(message),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('تأكيد')),
          ],
        ),
      ),
    );
    return r ?? false;
  }
}

extension StringX on String {
  bool get isValidEgPhone => RegExp(r'^01[0125][0-9]{8}$').hasMatch(this);
}
