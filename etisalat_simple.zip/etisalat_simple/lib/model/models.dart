class UserModel {
  const UserModel({this.id, required this.name, required this.phone, required this.createdAt});
  final int? id;
  final String name;
  final String phone;
  final DateTime createdAt;

  factory UserModel.fromMap(Map<String, Object?> m) => UserModel(
        id: m['id'] as int?,
        name: m['name'] as String,
        phone: m['phone'] as String,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
  Map<String, Object?> toMap() =>
      {'id': id, 'name': name, 'phone': phone, 'created_at': createdAt.toIso8601String()};
}

class AppTransaction {
  const AppTransaction({
    this.id,
    required this.userPhone,
    required this.name,
    required this.phone,
    required this.amount,
    required this.type,
    this.note,
    required this.createdAt,
  });
  final int? id;
  final String userPhone;
  final String name;
  final String phone;
  final double amount;
  final String type; // send | receive
  final String? note;
  final DateTime createdAt;

  bool get isSend => type == 'send';
  double get signedAmount => isSend ? -amount : amount;

  factory AppTransaction.fromMap(Map<String, Object?> m) => AppTransaction(
        id: m['id'] as int?,
        userPhone: m['user_phone'] as String,
        name: m['name'] as String,
        phone: m['phone'] as String,
        amount: (m['amount'] as num).toDouble(),
        type: m['type'] as String,
        note: m['note'] as String?,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
  Map<String, Object?> toMap() => {
        'id': id,
        'user_phone': userPhone,
        'name': name,
        'phone': phone,
        'amount': amount,
        'type': type,
        'note': note,
        'created_at': createdAt.toIso8601String(),
      };
}

class NotificationModel {
  const NotificationModel({this.id, required this.title, required this.body, this.isRead = false, required this.createdAt});
  final int? id;
  final String title;
  final String body;
  final bool isRead;
  final DateTime createdAt;

  factory NotificationModel.fromMap(Map<String, Object?> m) => NotificationModel(
        id: m['id'] as int?,
        title: m['title'] as String,
        body: m['body'] as String,
        isRead: (m['is_read'] as int) == 1,
        createdAt: DateTime.parse(m['created_at'] as String),
      );
  Map<String, Object?> toMap() => {
        'id': id,
        'title': title,
        'body': body,
        'is_read': isRead ? 1 : 0,
        'created_at': createdAt.toIso8601String(),
      };
}
