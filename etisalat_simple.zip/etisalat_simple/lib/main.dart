import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/app_database.dart';
import 'cubit/cubits.dart';
import 'data/repositories.dart';
import 'screens/main_layout_screen.dart';
import 'screens/setup_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = await AppDatabase.open();
  runApp(App(db));
}

class App extends StatelessWidget {
  const App(this.db, {super.key});
  final AppDatabase db;

  @override
  Widget build(BuildContext context) {
    final settings = SettingsRepository(db);
    final users = UserRepository(db);
    final transactions = TransactionRepository(db);
    final notifications = NotificationRepository(db);

    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: settings),
        RepositoryProvider.value(value: users),
        RepositoryProvider.value(value: transactions),
        RepositoryProvider.value(value: notifications),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => UserCubit(users, settings)..load()),
          BlocProvider(create: (_) => TransactionCubit(transactions, settings)..load()),
          BlocProvider(create: (_) => NotificationCubit(notifications)..load()),
        ],
        child: MaterialApp(
          title: 'خدماتي',
          debugShowCheckedModeBanner: false,
          locale: const Locale('ar', 'EG'),
          supportedLocales: const [Locale('ar', 'EG')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: ThemeData(
            colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087C62)),
            useMaterial3: true,
          ),
          home: const _Gate(),
        ),
      ),
    );
  }
}

/// أول مرة: شاشة إدخال الاسم والرقم. بعد كده: التطبيق مباشرة.
class _Gate extends StatelessWidget {
  const _Gate();

  @override
  Widget build(BuildContext context) {
    final s = context.watch<UserCubit>().state;
    if (s.loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (s.user == null) return const SetupScreen();
    return const MainLayoutScreen();
  }
}
